//Question No 2

$(document).ready(function() {
    //Method-1
    $("p:even").append("<b>19-NTU-CS-1147</b>");
    
    //Method 2
    // $("<b>19-NTU-CS-1147</b>").appendTo("p:even");

});