//Question No 5

$(document).ready(function() {
    
    $("div.section").click(function(){
        $("div.section").animate({width: "800px", height: "800px"});
    }); 
});