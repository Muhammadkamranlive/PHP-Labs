//Question No 6

$(document).ready(function() {
    $("button.btn").click(function () { 
        var Company_Name = $('#C-name').val();
        var VAT = $('#vat').val();        
        var Card_Number = $('#card-number').val();        
        var Card_Holder_Name = $('#CH-name').val();        
        var exp_date = $('#exp-date').val();        
        var CVV = $('#CVV').val();

        alert("Company Name: " + Company_Name + "\nVAT: " + VAT + "\nCard Number: " + Card_Number +
        "\nCard Holder Name: " + Card_Holder_Name + "\nExp. Date: " + exp_date + "\nCVV: " + CVV);
    });

});