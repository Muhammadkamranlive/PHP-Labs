//Question No 7

$(document).ready(function(){
    $("button").click(function(){
      $("div#ahmad").slideToggle();
    });
});