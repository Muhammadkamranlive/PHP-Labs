//Question No 10

$(document).ready(function() {
    
    $("button.btn").click(function () { 
        
        var x = $("#x").val();
        var y = $("#y").val();
        var z = $("#z").val();

        var sum = Number(x) + Number(y) + Number(z) ;

        $("#sum").val(sum);

    });
    
});