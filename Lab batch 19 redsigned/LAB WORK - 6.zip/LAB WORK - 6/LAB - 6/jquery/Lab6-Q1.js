//Question No 1

$(document).ready(function() {
    
    $("p:even").css("background-color" , "green");
    $("p:odd").css("background-color" , "yellow");
    
});