//Question No 8

$(document).ready(function() {
    $("button").click(function () { 
        // Method 1
        var count_elements = $("ul:eq(4) .list").length;
        
        // Method 2
        // var count_elements = $("ul:eq(4)").children().length;

        alert("Li elements in UL Tag: " + count_elements);
    });
    
});