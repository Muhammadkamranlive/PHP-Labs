//Question 9

$(document).ready(function() {
    $(".btn-1").click(function() {    
        
        $("#img-1").attr("src", "images/workplace-2.jpg");
    
    });

    $(".btn-2").click(function() {    
        
        $("#img-1").attr("src", "images/workplace-1.jpg");
    
    });

    $(".btn-3").click(function() {    
        
        $("#img-2").attr("src", "images/workplace-4.jpg");
    
    });

    $(".btn-4").click(function() {    
        
        $("#img-2").attr("src", "images/workplace-3.jpg");
    
    });
    
});