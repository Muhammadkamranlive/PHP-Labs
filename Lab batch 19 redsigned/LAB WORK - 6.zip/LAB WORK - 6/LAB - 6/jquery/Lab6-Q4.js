//Question No 4

$(document).ready(function() {
    $("button").click(function () { 
        var count_elements = $('p').length;
        alert("Paragraphs in this HTML Page: " + count_elements);
    });
    
});