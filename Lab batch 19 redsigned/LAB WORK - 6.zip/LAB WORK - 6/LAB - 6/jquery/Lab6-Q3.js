//Question No 3

$(document).ready(function() {
    
    $("p.para-5").text("19-NTU-CS-1147");
    
});