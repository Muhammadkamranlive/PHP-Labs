<?php
    class DataBase {
        public $conn;

        function __construct(){
            $this->conn = new PDO("mysql:host=localhost; dbname=final","root","");

        }



        function fetch(){
            $fetch = $this->conn->query("SELECT * FROM student");
            $res = $fetch->fetchAll();
            return $res;
        }


        function delete($id){
            $delete = $this->conn->prepare("DELETE FROM student WHERE ID=?");
            $delete->execute($id);

            try {
                $delete->rowCount();
                echo "successfull";
                header("location:Dashboard.php");
            }

            catch (Exception $e) {
                echo "Error: " . $e->getMessage();
            }
        }

        function auth() {
            $fetch = $this->conn->query("SELECT * FROM login");
            $res = $fetch->fetchAll();
            return $res;
        }


    }
?>