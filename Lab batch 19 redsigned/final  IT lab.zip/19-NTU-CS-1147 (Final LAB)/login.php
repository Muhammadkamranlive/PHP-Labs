<?php
    require_once "dbconn.php";


    if(isset($_POST["login"])){
        $username = $_POST["username"];
        $password = $_POST["password"];

        $obj = new DataBase();

        $result = $obj->auth();

        foreach($result as $row){
            if($row[1]==$username && $row[2]==$password){
                
                setcookie("rememberme",$row[1], time()+3600);

                header("location:Dashboard.php");
            }

        }
        
    }

?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css"
        integrity="sha384-zCbKRCUGaJDkqS1kPbPd7TveP5iyJE0EjAuZQTgFLD2ylzuqKfdKlfG/eSrtxUkn" crossorigin="anonymous">
    <title>Login Form</title>
    <style>
        body {
            background-image: linear-gradient(to left, rgba(0, 0, 0, 0.8), rgba(0, 0, 0, 0.5)), url('./laptop.jpg');
            background-size: cover;
            background-position: top;
            font-family: cursive;
        }
    </style>
</head>

<body>

    <div class="container mt-5 w-75 p-5">
        <form action="login.php" method="post" class="form text-light border p-5 mt-5">
        <h1 class="text-center text-primary">Login Form</h1>
            <div class="form-group">
                <label for="" >Username</label>
                <input type="text" name="username" id="name" class="form-control" placeholder="Enter Username">
            </div>
            <div class="form-group">
                <label for="">Password</label>
                <input type="password" name="password" id="pass" class="form-control" placeholder="Enter Password">
            </div>
            <div class="text-center">
                <button type="submit" name="login" class="btn btn-lg btn-primary px-4 mt-2">Login</button>
            </div>
        </form>
    </div>
</body>

</html>