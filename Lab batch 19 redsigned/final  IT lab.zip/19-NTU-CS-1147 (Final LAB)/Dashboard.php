<?php
    require_once "dbconn.php";
    
    if(!isset($_COOKIE["rememberme"])){
        header("location:login.php");
    }

    $obj = new DataBase();

    $result = $obj->fetch();
    if(isset($_COOKIE["rememberme"])){
        echo '<div class="text-right text-light px-5 py-3">
        <a class="btn btn-primary mr-3" href="logout.php">Logout</a>'.$_COOKIE["rememberme"].'        
        </div>';
    
    }
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css"
        integrity="sha384-zCbKRCUGaJDkqS1kPbPd7TveP5iyJE0EjAuZQTgFLD2ylzuqKfdKlfG/eSrtxUkn" crossorigin="anonymous">
    <title>Dashboard</title>
    <style>
        body {
            background-image: linear-gradient(to left, rgba(0, 0, 0, 0.8), rgba(0, 0, 0, 0.5)), url('./laptop.jpg');
            background-size: cover;
            background-position: top;
            font-family: cursive;
        }
    </style>
</head>

<body>
    <div class="container-fluid px-5 mt-5">
        <table class="table col-12 text-light text-center">
            <thead class="thead-dark">
                <tr>
                    <th scope="col">Student ID</th>
                    <th scope="col">Student Name</th>
                    <th scope="col">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    foreach($result as $row){
                        echo '<tr>';
                        echo '<th scope="row">' . $row["2"] . '</td>';
                        echo '<td>' . $row["1"] . '</td>';
                        echo '<td><a href="delete_record.php?id='.$row[0].'"  class="btn btn-danger">Delete</a></td>';
                        echo '</tr>';

                    }
                ?>
            </tbody>
        </table>
    </div>

</body>

</html>