<?php

    require_once("dbconn.php");

    $obj = new DataBase();

    $obj->delete(array($_GET['id']));

?>